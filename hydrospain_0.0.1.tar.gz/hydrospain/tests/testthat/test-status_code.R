test_that("multiplication works", {
 
  expect_identical(status_code("http://r-project.org"), 200L)
  
})
